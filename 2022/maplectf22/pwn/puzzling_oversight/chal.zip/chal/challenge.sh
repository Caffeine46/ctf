#!/usr/bin/bash
cd /ctf
./chal
