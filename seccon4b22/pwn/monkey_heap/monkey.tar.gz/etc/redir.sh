#! /bin/bash
cd /home/pwn && ./chall
